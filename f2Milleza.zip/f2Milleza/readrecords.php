<?php
include 'connect.php';

if (!$connection) {
    die('Could not connect: ' . mysqli_connect_error());
}

$query = "
    SELECT 
        u.fname, 
        u.lname, 
        o.name AS org_name, 
        og.position, 
        og.role,
        (SELECT SUM(budget) FROM tblorganization) AS total_budget,
        (SELECT SUM(cost) FROM tblsponsor) AS total_cost
    FROM tblorganizer og
    JOIN tbluser u ON og.student_id = u.student_id
    JOIN tblorganization o ON og.organization_id = o.organization_id
";

$resultset = mysqli_query($connection, $query);

// Fetch the total budget and total cost from the first row of the result set
if ($row = mysqli_fetch_assoc($resultset)) {
    $totalBudget = $row['total_budget'];
    $totalCost = $row['total_cost'];
} else {
    $totalBudget = 0;
    $totalCost = 0;
}

if ($orgRow = mysqli_fetch_assoc($resultset)) {
    $orgName = $orgRow['org_name'];  // Save the organization name
} else {
    $orgName = "No organization available";  // Default message if no result
}

// Reset the result set pointer to retrieve the rest of the data
mysqli_data_seek($resultset, 0);
?>
