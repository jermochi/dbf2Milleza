<?php    
    include 'connect.php';
    include 'readrecords.php';   
    include 'header.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Records</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-image: url('./index_files/bg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100%;
            overflow-y: auto;
        }

        header{
            background-color: rgba(136, 201, 107, 0.5);
            width: 100%;
            padding-left: 50px;
            color: white;
            display: flex;
            align-items: center;
        }

        .button-container {
            margin: 20px;
            text-align: center;
        }

        .button-container button {
            padding: 10px 50px;
            font-size: 16px;
            background-color: #348434;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }

        .button-container button:hover {
            background-color: #287028;
        }

        .table-container {
            margin:  auto;
            padding: 20px 30px;
            background-color: white;
            width: 80%;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .table-container th, .table-container td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .table-container th {
            background-color: #348434;
            color: white;
        }

        .table-container tr:nth-child(odd) {
                background-color: #ffffff; /* White color for odd rows */
        }

        .table-container tr:nth-child(even) {
            background-color:rgb(235, 235, 235); /* Light gray color for even rows */
        }

        .table-container td button {
            padding: 5px 10px;
            background-color: #da6856;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .table-container td button:hover {
            background-color: #b1574b;
        }

        footer {
            background-color: rgba(136, 201, 107, 0.1);
            width: 100%;
            text-align: center;
            font-weight: bold;
            font-size: 20px;
            color: white;
            padding: 10px;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .chart-container {
            width: 300px;       
            height: 300px;       
            margin: 20px auto;    
            padding: 10px;
        }

    </style>
</head>
<body>

    <div class="button-container">
        <button><a href="index.php" style="color: white; text-decoration: none;">Logout</a></button>
    </div>
    <div style="text-align: center; margin-bottom: 10px; color: #14453b">
        <h1><?php echo htmlspecialchars($orgName); ?></h1>
    </div>

    <div class="chart-container">
        <canvas id="budgetPieChart"></canvas>
    </div>

    <br>

    <div class="table-container">
        <table id="tblCustomerRecords" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%"> 
        <p style="color: #ffffff"><h1>List of Organizers</h1></p>
            <thead>
                <tr> 
                    <th>First Name</th> 
                    <th>Last Name</th> 
                    <th>Affiliated Organization</th>
                    <th>Position</th>                     
                    <th>Role</th>
                </tr> 
            </thead>  
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($resultset)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['fname']); ?></td>
                        <td><?php echo htmlspecialchars($row['lname']); ?></td>
                        <td><?php echo htmlspecialchars($row['org_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['position']); ?></td>
                        <td><?php echo htmlspecialchars($row['role']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>         
        </table>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>

        var budget = <?php echo $totalBudget; ?>;
        var totalCost = <?php echo $totalCost; ?>;

        var freeBudget = budget - totalCost;

        var data = {
            labels: ['Budget Used', 'Budget Free'],
            datasets: [{
                data: [totalCost, freeBudget],
                backgroundColor: ['#fff1ee', '#28a745'],
                hoverBackgroundColor: ['#FF5733', '#28a745']
            }]
        };

        var ctx = document.getElementById('budgetPieChart').getContext('2d');
        var budgetPieChart = new Chart(ctx, {
            type: 'pie',
            data: data
        });
    </script>

</body>
</html>

<?php include 'footer.php';  ?>
